# Smart Web Assistant (Chrome Extension)

An AI-powered Google Chrome extension (built on Manifest V3) that allows you to have deep-dive conversations with the Gemini API regarding the active webpage you are browsing.

## 🚀 Features
- **Automated Scraping:** Intelligently extracts raw text content from your active tab while ignoring structural noise.
- **Persistent Memory:** Utilizes stateful conversational logic to handle continuous multi-turn follow-up questions.
- **Context Preservation:** Injects relevant website elements seamlessly directly into the context stream window.

## 🛠️ Installation & Setup
1. Open `popup.js` and replace `YOUR_GEMINI_API_KEY` with a valid string token from Google AI Studio.
2. Launch Google Chrome and navigate to `chrome://extensions/`.
3. Toggle the **Developer mode** slider in the top right corner to **ON**.
4. Click **Load unpacked** in the top left corner.
5. Select this project folder.
